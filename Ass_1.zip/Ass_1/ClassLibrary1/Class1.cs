﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ass_1;
using NUnit.Framework;

namespace ClassLibrary1
{
    [TestFixture]
    class ClassLibrary1
    {
        [Test]
        public void GetLength_input2_ExpectedLengthEquals2()
        {
            //Arrange
            int l = 6;
            int w = 4;
            Rectangle testRect = new Rectangle(l, w);

            //Act
            int length = testRect.GetLength();

            //Assert
            Assert.AreEqual(l, length);
        }
        [Test]
        public void GetWidth_input7_ExpectedWidthEquals7()
        {
            //Arrange
            int l = 2;
            int w = 9;
            Rectangle testRect = new Rectangle(l, w);

            //Act
            int width = testRect.GetWidth();

            //Assert
            Assert.AreEqual(w, width);
        }
        [Test]
        public void SetLength_input2_ExpectedLengthEquals2()
        {
            //Arrange
            int l = 6;
            int w = 2;
            Rectangle testRect = new Rectangle(l, w);

            //Act
            int actLength = testRect.SetLength(l);

            //Assert
            Assert.AreEqual(l, actLength);
        }
        [Test]
        public void SetWidth_input3_ExpectedWidthEquals3()
        {
            //Arrange
            int l = 5;
            int w = 5;
            Rectangle testRect = new Rectangle(l, w);

            //Act
            int actWidth = testRect.SetWidth(w);

            //Assert
            Assert.AreEqual(w, actWidth);
        }
        [Test]
        public void GetPerimeter_inputLength3_inputWidth4_ExpectedPerimeterEquals14()
        {
            //Arrange
            int l = 3;
            int w = 4;
            Rectangle testRect = new Rectangle(l, w);
            int expectedResult = 2 * (l + w);
             
            //Act
            int actPerimeter = testRect.GetPerimeter();

            //Assert
            Assert.AreEqual(expectedResult, actPerimeter);
        }
        [Test]
        public void GetArea_inputLength3_inputWidth9_ExpectedPerimeterEquals27()
        {
            //Arrange
            int l = 3;
            int w = 9;
            Rectangle testRect = new Rectangle(l, w);
            int expectedResult = l * w;

            //Act
            int actArea = testRect.GetArea();

            //Assert
            Assert.AreEqual(expectedResult, actArea);
        }
      
    }
}
