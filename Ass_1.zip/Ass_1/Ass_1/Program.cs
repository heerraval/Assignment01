﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ass_1
{
    class Program
    {
        public static int getMenuInput()
        {
            string ui = "";
            bool flag = false;

            while (flag == false)
            {
                Console.WriteLine("1. Show Rectangle's Length");
                Console.WriteLine("2. Reset Rectangle's Length");
                Console.WriteLine("3. Show Rectangle's Width");
                Console.WriteLine("4. Change Rectangle's Width");
                Console.WriteLine("5. Rectangle's Area");
                Console.WriteLine("6. Calculate Rectangle Perimeter");
                Console.WriteLine("7. Quit");

                Console.WriteLine("Select from 1-7");
                ui = Console.ReadLine();

                if (ui != "1" &&
                     ui != "2" &&
                     ui != "3" &&
                     ui != "4" &&
                     ui != "5" &&
                     ui != "6" &&
                     ui != "7")
                    Console.WriteLine("Try again");
                else
                    flag = true;
            }
            return int.Parse(ui);
        }

        public static int UserInputCheck(string inputNumber)
        {
            int aNumber = 1;
            bool isValid = false;

            while (isValid == false)
            {
                Console.Write("Enter the value: {0} = ", inputNumber);
                string getUserInput = Console.ReadLine();
                Console.WriteLine();

                bool result = int.TryParse(getUserInput, out aNumber);

                if (result == false)
                    Console.WriteLine("OOPS! Not a valid input, try again.\n");
                else
                    isValid = true;
            }
            return aNumber;
        }
        static void Main(string[] args)
        {

            int l = UserInputCheck("Length");
            int w = UserInputCheck("Width");

            Console.WriteLine("The size of Rectangle is {0} X {1}.\n", l, w);

            Rectangle r = new Rectangle(l, w);

            int UserChoice = getMenuInput(); 

            while (UserChoice != 7)
            {
                int result;
                switch (UserChoice)
                {
                    case 1:
                        Console.WriteLine("Rectangle's Length is: {0}\n", r.GetLength());
                        break;
                    case 2:
                        result = UserInputCheck("Length");
                        r.SetLength(result);
                        break;
                    case 3:
                        Console.WriteLine("Rectangle's Width: {0}\n", r.GetWidth());
                        break;
                    case 4:
                        result = UserInputCheck("Width");
                        r.SetWidth(result);
                        break;
                    case 5:
                        Console.WriteLine("Rectangle's Area: {0}\n", r.GetArea());
                        break;
                    case 6:
                        Console.WriteLine("Rectangle's Perimeter: {0}\n", r.GetPerimeter());
                        break;
                    case 7:
                        break;
                    default:
                        break;
                }
                UserChoice = getMenuInput();
            }
        }
    }
}
